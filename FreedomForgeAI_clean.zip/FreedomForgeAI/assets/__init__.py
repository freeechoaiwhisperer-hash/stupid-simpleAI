# FreedomForge AI — assets package
