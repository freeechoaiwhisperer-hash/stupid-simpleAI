# FreedomForge AI — core package
