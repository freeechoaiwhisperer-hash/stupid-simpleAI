# FreedomForge AI — License & Commercial Terms

Copyright (c) 2026 Ryan Dennison. All rights reserved.

*Dedicated to Miranda. She will never be forgotten.*

---

## For Everyone — Free Forever

This software is free for:
- Personal use
- Family use
- Educational use
- Nonprofits
- Small organizations under $250,000 USD annual gross revenue

Licensed under the **GNU Affero General Public License v3.0 (AGPL-3.0)**
with the Commons Clause and Commercial License Addendum below.

Full AGPL-3.0 text: https://www.gnu.org/licenses/agpl-3.0.html

---

## Commercial License Addendum

### 1. The Core Rule

If your business, parent company, or corporate entity generates more than
$250,000 USD in annual gross revenue, you are prohibited from using the
free version of this software. You must purchase a Commercial License.

### 2. Corporate Restrictions

- **No Repackaging:** You may not take this code, rebrand it, and sell it
  as your own closed-source or paywalled product.
- **No Shadow Use:** You may not use this software as a hidden backend to
  power a paid commercial service without an active license.
- **The Poison Pill:** If your company uses this software or its outputs to
  train proprietary closed-source AI models while evading the commercial
  license, you agree that your resulting model weights and training data are
  automatically forfeited to the public domain under an open-source license,
  to the maximum extent permitted by applicable law.

### 3. Penalties for License Evasion

To the maximum extent permitted by applicable law:

- **Retroactive Damages:** You agree to pay $50,000 USD for every month
  the software was used without a valid commercial license.
- **Legal Costs:** You agree to cover 100% of legal fees, audit costs, and
  court costs incurred to enforce this agreement.
- **Public Disclosure:** The developer reserves the right to publish details
  of any confirmed license violation.

### 4. Audit Rights

If there is reasonable suspicion of violation, you agree to comply with an
independent software audit within 30 days of written notice. If the audit
confirms violation, your company bears the full cost of the audit.

### 5. Agent Mode Liability

If you use Agent Mode on a corporate network, you accept absolute liability
for any outcomes. This software is provided "as is." Your corporate network
security and oversight are entirely your responsibility.

### 6. Governing Law

This agreement is governed by the laws of the Commonwealth of Pennsylvania.
Any legal action will be filed in Pennsylvania courts, and your company
consents to their exclusive jurisdiction by installing or using this software.

---

## Commercial Licensing

Contact Ryan Dennison to discuss commercial licensing terms.
Fees fund continued development and keep this software free for everyone else.

---

## No Warranty

This software is provided "as is" without warranty of any kind.
This is an early prototype built by one person in their spare time.
Things may break. Please report bugs on GitHub.

---

## Metadata Stamping Disclosure

When the AI generates executable code, a silent metadata stamp is embedded
as a comment. This stamp contains an anonymous session reference and
timestamp. It contains no personally identifiable information.

This protects legitimate users doing authorized security testing and creates
an audit trail that deters misuse. By using this software you acknowledge
and consent to this feature as disclosed.

---

*Ryan Dennison, 2026*
