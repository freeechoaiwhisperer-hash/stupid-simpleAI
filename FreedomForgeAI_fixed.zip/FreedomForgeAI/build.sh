#!/bin/bash
echo "================================================"
echo "FreedomForge AI - Linux Build"
echo "================================================"
pip install pyinstaller --quiet
pyinstaller --clean FreedomForge.spec
echo ""
echo "Build finished!"
echo "Binary: dist/FreedomForgeAI"
chmod +x dist/FreedomForgeAI 2>/dev/null || true
echo ""
echo "To create AppImage: ./make_appimage.sh"
