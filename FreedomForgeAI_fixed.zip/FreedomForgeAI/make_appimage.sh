#!/bin/bash
# FreedomForge AI - Linux AppImage Builder
set -e
APP_NAME="FreedomForgeAI"
APP_DIR="${APP_NAME}.AppDir"
ICON_SRC="assets/icon.png"
BINARY_SRC="dist/${APP_NAME}"
OUTPUT_APPIMAGE="${APP_NAME}.AppImage"

echo "================================================"
echo "FreedomForge AI - Building Linux AppImage"
echo "================================================"

if [ ! -f "$BINARY_SRC" ]; then
    echo "Error: $BINARY_SRC not found. Run ./build.sh first."
    exit 1
fi

rm -rf "$APP_DIR"
mkdir -p "$APP_DIR/usr/bin"
mkdir -p "$APP_DIR/usr/share/icons/hicolor/256x256/apps"

cp "$BINARY_SRC" "$APP_DIR/usr/bin/${APP_NAME}"
chmod +x "$APP_DIR/usr/bin/${APP_NAME}"
cp "$ICON_SRC" "$APP_DIR/${APP_NAME}.png"
cp "$ICON_SRC" "$APP_DIR/usr/share/icons/hicolor/256x256/apps/${APP_NAME}.png"

cat > "$APP_DIR/${APP_NAME}.desktop" << DESKTOP
[Desktop Entry]
Name=FreedomForge AI
Exec=${APP_NAME}
Icon=${APP_NAME}
Type=Application
Categories=Utility;AI;Chat;Development;
Comment=Free. Local. Private. For Everyone.
Terminal=false
DESKTOP

ln -sf "usr/bin/${APP_NAME}" "$APP_DIR/AppRun"
chmod +x "$APP_DIR/AppRun"

if [ ! -f "appimagetool-x86_64.AppImage" ]; then
    echo "Downloading appimagetool..."
    wget -q https://github.com/AppImage/AppImageKit/releases/download/continuous/appimagetool-x86_64.AppImage
    chmod +x appimagetool-x86_64.AppImage
fi

./appimagetool-x86_64.AppImage "$APP_DIR" "$OUTPUT_APPIMAGE"
chmod +x "$OUTPUT_APPIMAGE"

echo ""
echo "SUCCESS: $OUTPUT_APPIMAGE created"
echo "Run with: ./$OUTPUT_APPIMAGE"
