#!/bin/bash
# FreedomForge AI - macOS .app + .dmg Builder
set -e
APP_NAME="FreedomForge AI"
BUNDLE_NAME="FreedomForgeAI"
APP_BUNDLE="${BUNDLE_NAME}.app"
DMG_NAME="${BUNDLE_NAME}.dmg"
ICON_SRC="assets/icon.png"
BINARY_SRC="dist/FreedomForgeAI"
BUNDLE_ID="com.ryandennison.freedomforgeai"

echo "================================================"
echo "FreedomForge AI - Building macOS .app + .dmg"
echo "================================================"

if [ ! -f "$BINARY_SRC" ]; then
    echo "Error: $BINARY_SRC not found. Run ./build.sh first."
    exit 1
fi

rm -rf "$APP_BUNDLE"
mkdir -p "$APP_BUNDLE/Contents/MacOS"
mkdir -p "$APP_BUNDLE/Contents/Resources"
cp "$BINARY_SRC" "$APP_BUNDLE/Contents/MacOS/$BUNDLE_NAME"
chmod +x "$APP_BUNDLE/Contents/MacOS/$BUNDLE_NAME"

# Convert icon
ICONSET="icon.iconset"
mkdir -p "$ICONSET"
for size in 16 32 64 128 256 512 1024; do
    sips -z $size $size "$ICON_SRC" --out "$ICONSET/icon_${size}x${size}.png" 2>/dev/null || true
done
iconutil -c icns "$ICONSET" -o "$APP_BUNDLE/Contents/Resources/${BUNDLE_NAME}.icns" 2>/dev/null || \
    cp "$ICON_SRC" "$APP_BUNDLE/Contents/Resources/${BUNDLE_NAME}.png"
rm -rf "$ICONSET"

cat > "$APP_BUNDLE/Contents/Info.plist" << PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key><string>FreedomForge AI</string>
    <key>CFBundleDisplayName</key><string>FreedomForge AI</string>
    <key>CFBundleIdentifier</key><string>${BUNDLE_ID}</string>
    <key>CFBundleVersion</key><string>0.1.0</string>
    <key>CFBundleShortVersionString</key><string>0.1.0</string>
    <key>CFBundleExecutable</key><string>${BUNDLE_NAME}</string>
    <key>CFBundleIconFile</key><string>${BUNDLE_NAME}.icns</string>
    <key>CFBundlePackageType</key><string>APPL</string>
    <key>LSMinimumSystemVersion</key><string>11.0</string>
    <key>NSHighResolutionCapable</key><true/>
</dict>
</plist>
PLIST

DMG_STAGE="dmg_stage"
rm -rf "$DMG_STAGE"
mkdir -p "$DMG_STAGE"
cp -R "$APP_BUNDLE" "$DMG_STAGE/"
ln -s /Applications "$DMG_STAGE/Applications"

hdiutil create -volname "FreedomForge AI" \
               -srcfolder "$DMG_STAGE" \
               -ov -format UDZO "$DMG_NAME"
rm -rf "$DMG_STAGE"

echo ""
echo "SUCCESS!"
echo "App: $APP_BUNDLE"
echo "DMG: $DMG_NAME"
echo "First launch: right-click → Open to bypass Gatekeeper"
