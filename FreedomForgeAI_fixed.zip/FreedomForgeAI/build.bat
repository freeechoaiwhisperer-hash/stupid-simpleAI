@echo off
echo ================================================
echo FreedomForge AI - Windows Build (Single EXE)
echo ================================================
echo.
pip install pyinstaller --quiet
pyinstaller --clean FreedomForge.spec
echo.
echo Build finished!
echo Executable: dist\FreedomForgeAI.exe
echo.
pause
