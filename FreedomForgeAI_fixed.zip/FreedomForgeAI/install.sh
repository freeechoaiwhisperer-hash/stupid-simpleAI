#!/bin/bash
# ============================================================
#  FreedomForge AI — install.sh
#  One-click installer for Linux
#  Copyright (c) 2026 Ryan Dennison
#  Dedicated to Miranda.
# ============================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_NAME="FreedomForge AI"
VENV_DIR="$SCRIPT_DIR/venv"
DESKTOP="$HOME/Desktop"
APPS_DIR="$HOME/.local/share/applications"

clear
echo ""
echo "  ╔══════════════════════════════════════════╗"
echo "  ║         ⚒️   FreedomForge AI              ║"
echo "  ║    Free. Local. Private. For Everyone.   ║"
echo "  ╚══════════════════════════════════════════╝"
echo ""
echo "  Setting up your AI. This takes about 2-5 minutes."
echo "  Grab a coffee ☕"
echo ""

# ── Create required folders ──────────────────────────────────
mkdir -p "$SCRIPT_DIR/models"
mkdir -p "$SCRIPT_DIR/logs"
mkdir -p "$SCRIPT_DIR/plugins"
mkdir -p "$SCRIPT_DIR/backups"
mkdir -p "$SCRIPT_DIR/crash_reports"

# ── Check Python 3.8+ ────────────────────────────────────────
echo "  [1/6] Checking Python..."
if ! command -v python3 &>/dev/null; then
    echo ""
    echo "  ❌  Python 3 not found."
    echo "  Please install it: sudo apt install python3 python3-pip"
    exit 1
fi

PY_MINOR=$(python3 -c 'import sys; print(sys.version_info.minor)')
if [ "$PY_MINOR" -lt 8 ]; then
    echo "  ❌  Python 3.8 or higher required."
    exit 1
fi
echo "  ✅  Python 3 ready."

# ── Install system packages ───────────────────────────────────
echo "  [2/6] Installing system packages..."

# Kill stuck apt if needed
sudo killall apt apt-get 2>/dev/null || true
sleep 1

# tkinter
if ! python3 -c "import tkinter" &>/dev/null 2>&1; then
    sudo apt install python3-tk -y 2>/dev/null || \
        echo "  ⚠️   tkinter install failed — try: sudo apt install python3-tk"
fi

# Audio for voice features
sudo apt install portaudio19-dev python3-pyaudio -y 2>/dev/null || true

echo "  ✅  System packages ready."

# ── Virtual environment ──────────────────────────────────────
echo "  [3/6] Creating Python environment..."
if [ ! -d "$VENV_DIR" ]; then
    python3 -m venv "$VENV_DIR"
fi
source "$VENV_DIR/bin/activate"
pip install --upgrade pip --quiet
echo "  ✅  Environment ready."

# ── Core Python packages ──────────────────────────────────────
echo "  [4/6] Installing packages..."
pip install \
    customtkinter \
    psutil \
    gputil \
    requests \
    SpeechRecognition \
    pyttsx3 \
    cryptography \
    --quiet

# pyaudio (optional, for voice)
pip install pyaudio --quiet 2>/dev/null || \
    echo "  ⚠️   pyaudio skipped — voice input may not work."

echo "  ✅  Packages installed."

# ── AI engine ────────────────────────────────────────────────
echo "  [5/6] Installing AI engine..."
echo "        (This may take a few minutes...)"

# Detect NVIDIA GPU for CUDA build
if command -v nvidia-smi &>/dev/null 2>&1; then
    echo "  🎮  NVIDIA GPU found — building with GPU support..."
    CMAKE_ARGS="-DLLAMA_CUBLAS=on" FORCE_CMAKE=1 \
        pip install llama-cpp-python --quiet 2>/dev/null || \
        pip install llama-cpp-python --quiet 2>/dev/null || \
        echo "  ⚠️   GPU build failed, trying CPU build..." && \
        pip install llama-cpp-python --quiet 2>/dev/null || true
else
    pip install llama-cpp-python --quiet 2>/dev/null || \
        echo "  ⚠️   AI engine had issues. Try: pip install llama-cpp-python"
fi
echo "  ✅  AI engine ready."

# ── Desktop integration ───────────────────────────────────────
echo "  [6/6] Creating shortcuts..."

# Launch script
cat > "$SCRIPT_DIR/launch.sh" << LAUNCHER
#!/bin/bash
cd "$SCRIPT_DIR"
source "$SCRIPT_DIR/venv/bin/activate"
python3 "$SCRIPT_DIR/main.py" "\$@"
LAUNCHER
chmod +x "$SCRIPT_DIR/launch.sh"

# Desktop shortcut
mkdir -p "$DESKTOP"
cat > "$DESKTOP/FreedomForgeAI.desktop" << SHORTCUT
[Desktop Entry]
Version=1.0
Type=Application
Name=FreedomForge AI
GenericName=Local AI Assistant
Comment=Free. Local. Private. For Everyone.
Exec=$SCRIPT_DIR/launch.sh
Icon=$SCRIPT_DIR/assets/icon.png
Terminal=false
StartupNotify=true
Categories=Utility;Science;Education;
Keywords=AI;Chat;Local;Privacy;
SHORTCUT
chmod +x "$DESKTOP/FreedomForgeAI.desktop"

# Application menu entry
mkdir -p "$APPS_DIR"
cp "$DESKTOP/FreedomForgeAI.desktop" "$APPS_DIR/"
update-desktop-database "$APPS_DIR" 2>/dev/null || true

echo "  ✅  Shortcuts created."

# ── Done ─────────────────────────────────────────────────────
echo ""
echo "  ╔══════════════════════════════════════════╗"
echo "  ║    ✅  FreedomForge AI is installed!     ║"
echo "  ╚══════════════════════════════════════════╝"
echo ""
echo "  ▶  Double-click the FreedomForgeAI icon on your Desktop"
echo "  ▶  Or run: bash $SCRIPT_DIR/launch.sh"
echo ""
echo "  🪄  Dedicated to Miranda."
echo "      She will never be forgotten."
echo ""

# Launch
echo "  🚀  Launching FreedomForge AI..."
source "$VENV_DIR/bin/activate"
nohup python3 "$SCRIPT_DIR/main.py" > "$SCRIPT_DIR/logs/launch.log" 2>&1 &
echo "  FreedomForge AI is running."
echo ""
