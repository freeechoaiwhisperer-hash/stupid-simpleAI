# -*- mode: python ; coding: utf-8 -*-
block_cipher = None
a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('assets', 'assets'),
        ('core', 'core'),
        ('ui', 'ui'),
        ('modules', 'modules'),
        ('utils', 'utils'),
    ],
    hiddenimports=['customtkinter','llama_cpp','psutil',
                   'speech_recognition','pyttsx3','cryptography','PIL'],
    hookspath=[], hooksconfig={}, runtime_hooks=[], excludes=[],
    cipher=block_cipher, noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)
exe = EXE(pyz, a.scripts, a.binaries, a.zipfiles, a.datas, [],
    name='FreedomForgeAI', debug=False, strip=False, upx=True,
    console=False, icon='assets/icon.png',
)

