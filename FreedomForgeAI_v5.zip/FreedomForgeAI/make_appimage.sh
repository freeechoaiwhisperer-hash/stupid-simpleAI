#!/bin/bash
APP="FreedomForgeAI"
APP_DIR="${APP}.AppDir"
rm -rf "$APP_DIR" "${APP}.AppImage" 2>/dev/null
mkdir -p "$APP_DIR"
cp dist/$APP "$APP_DIR/"
cp assets/icon.png "$APP_DIR/${APP}.png"
cat > "$APP_DIR/${APP}.desktop" << DESKTOP
[Desktop Entry]
Name=FreedomForge AI
Exec=$APP
Icon=$APP
Type=Application
Categories=Utility;AI;
Comment=Free. Local. Private. For Everyone.
Terminal=false
DESKTOP
cat > "$APP_DIR/AppRun" << APPRUN
#!/bin/sh
cd "\$(dirname "\$0")"
exec ./$APP
APPRUN
chmod +x "$APP_DIR/AppRun" "$APP_DIR/${APP}.desktop" "$APP_DIR/$APP"
if [ ! -f appimagetool-x86_64.AppImage ]; then
    wget -q https://github.com/AppImage/appimagetool/releases/download/continuous/appimagetool-x86_64.AppImage
    chmod +x appimagetool-x86_64.AppImage
fi
./appimagetool-x86_64.AppImage "$APP_DIR"
echo "AppImage created: FreedomForgeAI.AppImage"

