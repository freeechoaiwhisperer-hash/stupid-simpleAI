"""Centralised path definitions for FreedomForge AI."""
from pathlib import Path

APP_ROOT    = Path(__file__).resolve().parent.parent
MODELS_DIR  = APP_ROOT / "models"
LOGS_DIR    = APP_ROOT / "logs"
CRASH_DIR   = APP_ROOT / "crash_reports"
ASSETS_DIR  = APP_ROOT / "assets"
CONFIG_FILE = APP_ROOT / "config.json"
KEY_FILE    = APP_ROOT / ".forge_key"

def ensure_dirs() -> None:
    for d in (MODELS_DIR, LOGS_DIR, CRASH_DIR, ASSETS_DIR):
        d.mkdir(parents=True, exist_ok=True)
