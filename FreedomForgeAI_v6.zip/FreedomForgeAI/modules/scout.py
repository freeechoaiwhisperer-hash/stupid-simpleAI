import importlib.util
from pathlib import Path


class Scout:
    def __init__(self, plugins_dir="plugins"):
        self.tools = {}
        self.plugins_dir = plugins_dir
        self._load_plugins()

    def _load_plugins(self):
        path = Path(self.plugins_dir)
        if not path.exists():
            return
        for py_file in path.glob("*.py"):
            mod_name = py_file.stem
            spec = importlib.util.spec_from_file_location(mod_name, py_file)
            mod = importlib.util.module_from_spec(spec)
            try:
                spec.loader.exec_module(mod)
            except Exception:
                continue
            triggers = getattr(mod, "TRIGGERS", [])
            handler = getattr(mod, "handle", None)
            if triggers and handler and callable(handler):
                self.register_tool(mod_name, triggers, handler)

    def register_tool(self, name, triggers, handler):
        self.tools[name] = {"triggers": triggers, "handler": handler}

    def route(self, message):
        if not isinstance(message, str):
            return None
        msg_lower = message.lower()
        for tool in self.tools.values():
            for trigger in tool["triggers"]:
                if msg_lower.startswith(trigger.lower()):
                    try:
                        return tool["handler"](message)
                    except Exception:
                        break
        return None

    def reload_plugins(self):
        self.tools = {}
        self._load_plugins()

    def list_tools(self):
        return list(self.tools.keys())
