#!/bin/bash
rm -rf build dist 2>/dev/null
pyinstaller --clean FreedomForge.spec
echo "Build complete: dist/FreedomForgeAI"
