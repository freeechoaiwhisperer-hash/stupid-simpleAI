@echo off
rmdir /s /q build dist 2>nul
pyinstaller --clean FreedomForge.spec
echo Build complete: dist\FreedomForgeAI.exe
pause
