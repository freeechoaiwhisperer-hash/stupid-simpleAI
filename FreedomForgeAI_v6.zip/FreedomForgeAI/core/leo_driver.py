try:
    from llama_cpp import Llama
    LLAMA_AVAILABLE = True
except ImportError:
    LLAMA_AVAILABLE = False


class LeoDriver:
    def __init__(self):
        self.models = {}
        self.primary_name = None

    def register_model(self, name: str, path: str, skills: list, is_primary: bool = False):
        self.models[name] = {
            "path": path,
            "skills": [s.lower() for s in skills],
            "instance": None
        }
        if is_primary or not self.primary_name:
            self.primary_name = name

    def _load_model(self, name: str):
        if name not in self.models:
            return None
        if not LLAMA_AVAILABLE:
            return None
        info = self.models[name]
        if info["instance"] is None:
            try:
                info["instance"] = Llama(
                    model_path=info["path"],
                    n_ctx=4096,
                    verbose=False
                )
            except Exception:
                info["instance"] = None
                return None
        return info["instance"]

    def _get_best_model(self, task_type: str) -> str:
        task = task_type.lower()
        for name, info in self.models.items():
            if task in info["skills"]:
                return name
        if self.primary_name:
            return self.primary_name
        return list(self.models.keys())[0] if self.models else None

    def route_task(self, task_type: str, prompt: str, **kwargs):
        name = self._get_best_model(task_type)
        if not name:
            raise RuntimeError("No models registered in LeoDriver")
        model = self._load_model(name)
        if not model:
            if name != self.primary_name and self.primary_name:
                model = self._load_model(self.primary_name)
            if not model:
                raise RuntimeError(f"Could not load model: {name}")
        response = model.create_completion(
            prompt,
            max_tokens=kwargs.get("max_tokens", 512),
            temperature=kwargs.get("temperature", 0.7)
        )
        return response["choices"][0]["text"].strip()

    def list_models(self):
        return {
            name: {
                "skills": info["skills"],
                "loaded": info["instance"] is not None
            }
            for name, info in self.models.items()
        }

    def unload_model(self, name: str):
        if name in self.models and self.models[name]["instance"]:
            self.models[name]["instance"] = None
