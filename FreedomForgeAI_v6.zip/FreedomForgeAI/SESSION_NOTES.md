# FreedomForge AI — Session Notes for Claude
## Bug Fixes, Changes & New Features Applied 2026-03-30/31

This document is a handoff note for any Claude session working with this codebase.
It covers everything fixed, changed, or built during the overnight dev session.

---

## Project Overview

FreedomForge AI is a local AI desktop app — Python 3.10+, customtkinter UI,
llama-cpp-python for LLM inference (GGUF models), no cloud, no subscriptions.

**Two versions exist:**
- `/home/echo/Downloads/FreedomForgeAI` — lite base (has a working venv)
- `/home/echo/Documents/FreedomForgeAI` — full version (this codebase)

Both were kept in sync during this session. The Documents version is the primary one going forward.

**Startup flow:**
`main.py` → `SplashScreen` → `TermsDialog` (if not accepted) → `_check_models` → `SetupWizard` (if no models) → `_build_ui` → main app

---

## Architecture Notes

### Absolute Paths (Critical)
All paths are managed through `utils/paths.py`. Every core module imports from there.
**Never use relative paths** — the app can be launched from any CWD.

```python
# utils/paths.py
APP_ROOT    = Path(__file__).resolve().parent.parent
MODELS_DIR  = APP_ROOT / "models"
LOGS_DIR    = APP_ROOT / "logs"
CRASH_DIR   = APP_ROOT / "crash_reports"
ASSETS_DIR  = APP_ROOT / "assets"
CONFIG_FILE = APP_ROOT / "config.json"
KEY_FILE    = APP_ROOT / ".forge_key"
```

### Startup Bootstrap (main.py)
```python
from utils.paths import ensure_dirs
ensure_dirs()               # Must run FIRST before any other imports
from core import logger, config, encryption, crash_reporter
```

### Personalities
Unlocked with code `"MIRANDA"` in Settings → Special Features.
- `normal` — warm, helpful, direct
- `unhinged` — chaos mode, no filter
- `focused` — precision/technical mode

Miranda is a memorial to a deceased person important to the creator (Ryan Dennison).
The Miranda popups, wizard quotes, and About page all reference her. Treat this with respect.

---

## Bug Fixes Applied

### 1. `main.py` — Wrong function name
**Error:** `AttributeError: module 'core.crash_reporter' has no attribute 'install_global_handler'`
**Fix:** Renamed call to `crash_reporter.install_handler()`

### 2. `ui/terms_tab.py` — Missing TermsDialog class
**Error:** `ImportError: cannot import name 'TermsDialog' from 'ui.terms_tab'`
**Fix:** Added complete `TermsDialog(ctk.CTkToplevel)` class.
It wraps `TermsPanel`, has Accept/Decline buttons, calls `on_accept` or `on_decline` callbacks.

### 3. `ui/app.py` — App invisible after accepting terms
**Cause:** `self.withdraw()` is called during splash. `SetupWizard` was launched without
calling `self.deiconify()` first, so the wizard ran invisibly.
**Fix:** Added `self.deiconify()` before `SetupWizard()` in `_check_models()`.

### 4. `ui/app.py` — Wizard leaves orphaned widgets
**Cause:** `SetupWizard` packs plain `tk.Frame` widgets directly onto the main App window.
When `_wizard_done` fired, those widgets persisted behind the new CTk UI.
**Fix:** `_wizard_done()` destroys all children before calling `_build_ui()`:
```python
def _wizard_done(self):
    for w in self.winfo_children():
        try:
            w.destroy()
        except Exception:
            pass
    self.deiconify()
    self._build_ui()
    self._auto_load()
    self._schedule_miranda()
```

### 5. `ui/chat.py` — font= forbidden in tag_config
**Error:** `AttributeError: 'font' option forbidden` on CTkTextbox.tag_config
**Cause:** customtkinter forbids `font=` in `tag_config` due to internal DPI scaling.
**Fix:** Removed `font=` from all `tag_config` calls. Only `foreground=` is safe.

### 6. `ui/app.py` — Duplicate nav items
**Cause:** Privacy and Terms appeared twice in the nav_items list.
**Fix:** Cleaned nav_items to exactly one entry per panel.

### 7. All modules — Relative paths
**Cause:** `config.json`, `./models`, `logs/`, `crash_reports/`, `.forge_key` were all
relative paths. App breaks when not launched from the project root directory.
**Fix:** Created `utils/paths.py`, updated all core modules to import from it:
- `core/config.py` → `CONFIG_FILE`
- `core/logger.py` → `LOGS_DIR`
- `core/crash_reporter.py` → `CRASH_DIR`
- `core/encryption.py` → `KEY_FILE`
- `core/privacy.py` → `KEY_FILE`, `APP_ROOT`
- `core/model_manager.py` → `MODELS_DIR`
- `ui/models_tab.py` → `MODELS_DIR`

### 8. `utils/paths.py` — Missing KEY_FILE
**Error:** `ImportError: cannot import name 'KEY_FILE' from 'utils.paths'`
**Fix:** Added `KEY_FILE = APP_ROOT / ".forge_key"` to `utils/paths.py`.

### 9. `ui/wizard.py` — Missing SetupWizard class
**Error:** `ImportError: cannot import name 'SetupWizard' from 'ui.wizard'`
**Cause:** File only had `FreedomForgeWizard`. `app.py` imports `SetupWizard`.
**Fix:** Added `SetupWizard` class with signature `__init__(self, root, on_complete=None, theme_name=None)`.
Calls `on_complete()` when wizard finishes instead of destroying the window.

### 10. `core/privacy.py` (Documents version) — Multiple critical bugs
This file was entirely rewritten. Issues found:
- Hard `from cryptography.fernet import Fernet` with no try/except → NameError if not installed
- `CRYPTO_AVAILABLE = True` hardcoded on line 31 **after** the try/except, overriding it
- `generate_key()` called `Fernet.generate_key()` without checking CRYPTO_AVAILABLE
- `load_key(path)` required a path arg but `privacy_tab.py` calls `privacy.load_key()` with no args
- `save_key(key, path)` required path but tab calls `privacy.save_key(key)` with no path
- `get_or_create_key()` was missing entirely — called by `privacy_tab.py`
- `vpn_connect(tool, on_result)` — `tool` was required positional, callers used keyword-only
- `vpn_disconnect(tool, on_result)` — same issue
**Fix:** Complete rewrite matching the Downloads version's correct implementation.

### 11. Desktop shortcut — Wrong working directory
**Cause:** `.desktop` file had no `Path=` directive. App launched from `~` and all
relative paths broke even when they existed.
**Fix:** Added `Path=/path/to/FreedomForgeAI` to both `.desktop` files.

---

## New Files Created

| File | Purpose |
|------|---------|
| `utils/__init__.py` | Package marker |
| `utils/paths.py` | Centralized absolute path management |
| `core/system_tools.py` | Phase 3 backend: system scanning, startup programs, disk tools |
| `ui/system_tab.py` | Phase 3 UI: System Intelligence panel |

---

## Phase 3: System Intelligence (New Feature)

New sidebar tab: **🖥️ System** — added to nav between Privacy and Settings.

### `core/system_tools.py` — what it does:
- `get_system_summary()` — CPU (model, cores, usage), RAM, disk per mount, GPU via nvidia-smi, temps
- `get_health_report(summary)` — converts raw data to plain English for non-technical users
- `get_startup_programs()` — reads XDG autostart (`~/.config/autostart/*.desktop`) and systemd user services
- `disable_startup_item(item)` — writes `Hidden=true` to .desktop or runs `systemctl --user disable`
- `find_large_files(root, min_mb, max_results)` — walks home dir, returns files over threshold sorted by size
- `find_temp_files()` — checks `~/.cache`, `/tmp`, `~/.thumbnails`, Trash for size estimates

### `ui/system_tab.py` — UI sections:
1. **Full Health Check** — "Scan My Computer" button → runs scan in background thread → displays plain English report
2. **Live Stats** — 4 stat boxes (CPU%, RAM%, GPU%, Disk I/O) auto-updating every 1.5s
3. **Startup Programs** — lists autostart entries, Disable button for XDG entries
4. **Disk Cleaner** — two buttons: "Find Large Files" (>50MB) and "Find Junk/Cache"

### Wired into:
- `ui/app.py` — import, nav item, panel construction in `_build_ui()` and `apply_theme()`
- `app.py` (root) — same changes mirrored

---

## Key Things to Know About This Codebase

### customtkinter gotchas
- `tag_config()` on `CTkTextbox` does NOT accept `font=` — CTk uses internal scaling
- Only `foreground=`, `background=`, `underline=`, `overstrike=` etc. are safe
- `CTkToplevel` windows need `grab_set()` to be modal

### Threading pattern
All model loading, VPN ops, network kill, and scans run in daemon threads.
Results come back via `self.after(0, callback)` to safely touch the UI from threads.

### Config system
- `core/config.py` reads/writes `config.json` in APP_ROOT
- `ui/wizard.py` writes to `~/.freedomforge/config.json` — this is intentionally separate
- `config.get("terms_accepted", False)` — terms flag lives in APP_ROOT config
- `config.get("unlocked", False)` — personality unlock flag

### Miranda popup guard
`self._miranda_open` bool on the App instance prevents stacking popups.
Always check this flag before showing a new Miranda popup.

---

## What Still Needs Work (Known Gaps)

- `llama-cpp-python` not installed in Documents venv (large binary, optional — app handles it gracefully with `LLAMA_AVAILABLE` check)
- `pyaudio` not installed — voice input won't work until `portaudio19-dev` + `pyaudio` installed
- `GPUtil` not installed — GPU% shows 0 unless added (optional)
- Phase 3 startup disabling only works for XDG autostart entries, not systemd services (systemd path exists but needs testing)
- Phase 4-10 of ROADMAP not started

---

## Install / Run

```bash
# Documents version (full)
cd /home/echo/Documents/FreedomForgeAI
python3 -m venv venv
venv/bin/pip install -r requirements.txt
venv/bin/python3 main.py

# Downloads version (lite, venv already exists)
cd /home/echo/Downloads/FreedomForgeAI
venv/bin/python3 main.py
```

Desktop shortcuts on `~/Desktop/`:
- `FreedomForgeAI.desktop` → Downloads/lite version
- `FreedomForgeAI-Full.desktop` → Documents/full version
